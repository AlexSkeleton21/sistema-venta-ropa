import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity("productos") // Nombre de la tabla
export class Producto{
    @PrimaryGeneratedColumn()
    id:number = 0;
    @Column({length:100,nullable:false})
    nombre:string = "";
    @Column({type:'decimal',precision:10,scale:2})
    precio:number = 0;
}