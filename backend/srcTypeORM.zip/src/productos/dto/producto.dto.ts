import { IsString, IsNotEmpty, IsNumber, IsPositive } from "class-validator";

export class CreaProductoDto{
    @IsString({ message: "El nombre debe ser una cadena "})
    @IsNotEmpty({ message: 'El nombre no puede ir vacio'})
    nombre: string = "";
    @IsNumber({}, {message: 'Valor no valido'})
    @IsPositive({ message: 'Precio no valido '})
    precio: number = 0;
}

export class ActualizaProductoDto{
    @IsString({ message: "El nombre debe ser una cadena "})
    @IsNotEmpty({ message: 'El nombre no puede ir vacio'})    
    nombre?: string;
    @IsNumber({}, {message: 'Valor no valido'})
    @IsPositive({ message: 'Precio no valido '})
    precio?: number;
}